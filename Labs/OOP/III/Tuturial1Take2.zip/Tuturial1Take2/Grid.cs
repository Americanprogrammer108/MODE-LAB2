﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuturial1Take2
{
    public class Grid
    {
        //Data attributes representing the grid.
        private int yMax;
        private int yMin;
        private int xMax;
        private int xMin;

        //Constructor
        public Grid(int xMin, int xMax, int yMin, int yMax)
        {
            this.xMax = 2;
            this.yMin = 0;
            this.xMin = 0;
            this.yMax = 3;
        }
        //Method to check range.
        public bool CheckRange(int x, int y)
        {
            if (x > xMin || x < xMax || y > yMin || y < yMax)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        public int XMax
        {
            get
            {
                return xMax;
            }
            set
            {

                if (value > xMin)
                {
                    xMax = value;

                }
                else
                {
                    Console.WriteLine("That was invalid, you cannot do that because xMax is not greater than xMin.");
                }

            }
        }
        public int XMin
        {
            get
            {
                return xMin;
            }
            set
            {

                if (value < xMax)
                {
                    xMin = value;
                }
                else
                {
                    Console.WriteLine("That was invalid, you cannot do that because xMin is not less than xMax");
                }

            }
        }
        public int YMax
        {
            get
            {
                return yMax;
            }
            set
            {
                yMax = value;
            }
        }
        public int YMin
        {
            get
            {
                return yMin;
            }
            set
            {
                yMin = value;
            }
        }

        public string Quadrant(int x, int y)
        {

            if (x >= 0 && y >= 0)
            {
                return "This point is in Quadrant 1";
            }
            else if (x < 0 && y >= 0)
            {
                return "This point is in Quadrant 2";
            }
            else if (x < 0 && y < 0)
            {
                return "This point is in Quadrant 3";

            }
            else if (x >= 0 && y < 0)
            {
                return "This point is in Quadrant 4";
            }
            else
            {
                return "Out of bounds!";
            }
        }

    }
}
