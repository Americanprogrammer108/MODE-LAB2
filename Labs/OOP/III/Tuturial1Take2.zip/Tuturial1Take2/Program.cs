﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuturial1Take2
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Grid grid1 = new Grid(-10, 10, -10, 10);

            Console.WriteLine("The point x:{0},y:{1} is {2}", 2, 0, grid1.CheckRange(2, 0));
            Console.WriteLine("The point x:{0},y:{1} is {2}", 12, 18, grid1.CheckRange(12, 18));



            Console.WriteLine(grid1.Quadrant(1, 3));
            Console.WriteLine(grid1.Quadrant(-1, 4));
            Console.WriteLine(grid1.Quadrant(2, -1));
            Console.WriteLine(grid1.Quadrant(4, -4));
            Console.WriteLine(grid1.Quadrant(12, 18));

        }
    }
}
