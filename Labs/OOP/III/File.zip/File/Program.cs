﻿using System;
using System.Collections.Generic;

namespace File
{
    internal class Program
    {
        static void Main(string[] args)
        {

            List<File> files = new List<File>();

            File file1 = new File(new DateTime(2018, 10, 18), "Land Acknowledgment", 1048, new DateTime(2021, 4, 18), ".txt");
            File file2 = new File(new DateTime(2017, 12, 29), "Takeoff Checklist", 2182, new DateTime(2022, 4, 10), ".txt");
            File file3 = new File(new DateTime(2012, 4, 12), "Climb Checklist", 937, new DateTime(2019, 1, 4), ".txt");
            File file4 = new File(new DateTime(2013, 7, 11), "Descent Checklist", 1561, new DateTime(2021, 1, 30), ".txt");
            File file5 = new File(new DateTime(2016, 9, 4), "Taxi to Parking Checklist", 718, new DateTime(2018, 2, 5), ".txt");
            File file6 = new File(new DateTime(2012, 3, 29), "Sam", 98, new DateTime(2015, 12, 18), ".jpeg");
            File file7 = new File(new DateTime(2001, 2, 28), "NBA TV Schedule", 8107, new DateTime(2022, 7, 31), ".txt");
            File file8 = new File(new DateTime(1815, 7, 4), "Map of Boston", 47125, new DateTime(2021, 6, 11), ".txt");
            File file9 = new File(new DateTime(1999, 11, 14), "Shutdown Checklist", 1048, new DateTime(2018, 4, 18), ".txt");
            File file10 = new File(new DateTime(2015, 12, 19), "List of ATC Quotes", 3883, new DateTime(2018, 12, 04), ".txt");

            //add the files to the list
            files.Add(file1);
            files.Add(file2);
            files.Add(file3);
            files.Add(file4);
            files.Add(file5);
            files.Add(file6);
            files.Add(file7);
            files.Add(file8);
            files.Add(file9);
            files.Add(file10);



            //and return files with a size greater than 100
            File.sortbySize(files);

            //now, let's sort files by date
            File.sortbyDate(files);

            //file name from A-Z
            var alphabeticalorder = File.sortAtoZ(files);
            Console.WriteLine("Sorted files by alphabetical order:");
            
            foreach(File file in alphabeticalorder)
            {
                Console.WriteLine(file);
            }

            var sizeorder = File.sortbySize(files);
            Console.WriteLine("\nSorted files by size:");
            foreach(File file in sizeorder)
            {
                Console.WriteLine(file);
            }

            var dateorder = File.sortbyDate(files);
            Console.WriteLine("\nSorted files by date:");
            foreach(File file in files)
            {
                Console.WriteLine(file);
            }

            //Console.WriteLine(files.ToString());
        }
    }
}
