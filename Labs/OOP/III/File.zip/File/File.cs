﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File
{
    class File
    {
        private DateTime created;
        private string fileName;
        private double size;
        private DateTime lastEdited;
        private string fileType;

        List<File> files = new List<File>();

        public File(DateTime createdate, string nameoffile, double filesize, DateTime editdate, string type)
        {
            setFileDate(createdate);
            setFileEdit(editdate);
            setFileName(nameoffile);
            setFileSize(filesize);
            setFileType(fileType);
        }
        
        public static List<File> sortAtoZ(List<File> files)
        {
            //let's sort the files from A-Z
            var alphabeticalsort = files.OrderBy(f => f.fileName).ToList();
            return files;
        }

        public static List<File> sortbyDate(List<File> file)
        {
            //sort by date
            var datesort = file.OrderBy(f => f.created).ToList();
            return file;
        }

        public static List<File> sortbySize(List<File> file)
        {
            //sort by size
            var sizesort = file.OrderBy(f => f.size).Where(f => f.size > 100).ToList();
            return file;
        }

        //all getters

        public DateTime getCreated()
        {
            return created;
        }
        public DateTime getLastEdited()
        {
            return lastEdited;
        }
        public string getFileType()
        {
            return fileType;
        }

        public double getFileSize()
        {
            return size;
        }
        
        public string getFileName()
        {
            return fileName;
        }
        //end of getters


        //start of setters
        public void setFileType(string Type)
        {
            fileType = Type;
        }
        public void setFileName(string Name)
        { 
            fileName = Name; 
        }

        public void setFileSize(double Size)
        {
            size = Size;
        }

        public void setFileDate(DateTime Date)
        {
            created = Date;
        }

        public void setFileEdit(DateTime EditDate)
        { 
            lastEdited = EditDate; 
        }
        //end of setters

        //methods
        public override string ToString()
        {
            return getFileName() + " created on: " + getCreated() + " with a size of: " + getFileSize();
        }
    }
}
