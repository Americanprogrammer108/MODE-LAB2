﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial5
{
    public class Box
    {
        private double length { get; set; }
        private double width { get; set; }
        private double height { get; set; }

        //start of getters
        public double Width()
        {
            return width;
        }        
        
        public double Length()
        {
            return length;
        }
        
        public double Height()
        {
            return height;
        }
        //end of getters

        //start of setters
        public void SetWidth(double mywidth)
        {
            if (width >= 0)
            {
                width = mywidth;
            }
            else
            {
                width = 0;
            }
        }        
        
        public void SetLength(double mylength)
        {
            if (width >= 0)
            {
                length = mylength;
            }
            else
            {
                length = 0;
            }
        }        
        
        public void SetHeight(double myheight)
        {
            if (width >= 0)
            {
                height = myheight;
            }
            else
            {
                height = 0;
            }
        }
        //end of setters


        //constructor
        public Box(double w, double h, double l)
        {
            SetWidth(w);
            SetLength(l);
            SetHeight(h);
        }


        //method to calculate the volume of the box
        public double Calculate()
        {
            return length * width * height;
        }

        public static bool operator == (Box box1, Box box2)
        {
            return box1.Calculate() == box2.Calculate();
        }        
        
        public static bool operator >= (Box box1, Box box2)
        {
            return box1.Calculate() >= box2.Calculate();
        }
        
        public static bool operator <= (Box box1, Box box2)
        {
            return box1.Calculate() <= box2.Calculate();
        }
        
        public static bool operator != (Box box1, Box box2)
        {
            return box1.Calculate() != box2.Calculate();
        }
    }
}
