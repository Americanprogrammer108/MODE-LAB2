﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Tutorial5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Box> boxes = new List<Box>();

            Console.WriteLine("Hello World!");
            Box box1 = new Box(3, 9, 10);
            Box box2 = new Box(1, 8, 23);
            Box box3 = new Box(10, 28, 4);
            Box box4 = new Box(7, 1.9, 38.1);
            Box box5 = new Box(43, 19.92, 20.10);
            Box box6 = new Box(4.1, 1.28, 3);
            Box box7 = new Box(12, 9, 5.4);
            Box box8 = new Box(7.12, 8.1, 10);
            Box box9 = new Box(10, 10, 10);
            Box box10 = new Box(2.54, 2.38, 7);
            
            boxes.Add(box1);
            boxes.Add(box2);
            boxes.Add(box3);
            boxes.Add(box4);
            boxes.Add(box5);
            boxes.Add(box6);
            boxes.Add(box7);
            boxes.Add(box8);
            boxes.Add(box9);
            boxes.Add(box10);
            boxes = SortUsingLINQ(boxes);
            foreach(Box b in boxes)
            {
                Console.WriteLine("The volume of the box is " + b.Calculate());
            }

        }
        //Challenge: Complete the method below and sort using the comparison operators
        //without using the LINQ operators
        public static List<Box> SortUsingLINQ(List<Box> boxes)
        {
            List<Box> SortedList = boxes.OrderBy(b => b.Calculate()).ToList();
            return SortedList;
        }
    }
}
