﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial2Take2
{
    class Book : Document
    {
        private string title;

        //constructor
        public Book(string v)
        {
            title = v;
        }

        //getter
        public string getTitle()
        {
            return title;
        }
    }

}
