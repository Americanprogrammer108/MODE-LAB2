﻿using DocumentFormat.OpenXml.Office2019.Excel.RichData2;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Tutorial2Take2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> authors = new List<string>();
            authors.Add("Andrew Llorens");
            DateTime nowdate = DateTime.Now;

    

            Document document1 = new Document(authors, nowdate);

            
            //email object
            Email email1 = new Email(authors, "Birthday");


            //book object
            Book book1 = new Book("The Old Man and the Sea");

            Console.WriteLine("Email to " + email1.getTo() + " Subject: " + email1.getsubject());
            Console.WriteLine("Book Title: " + book1.getTitle());
        }
    }
}