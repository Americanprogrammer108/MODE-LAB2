﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial2Take2
{
    class Document
    {
        public List<string> authors = new List<string>();
        private DateTime date = DateTime.Now;


        //constructors
        public Document()
        {

        }

        public Document(List<string> authors, DateTime nowdate)
        {
            this.authors = authors;
            this.date = nowdate;
        }

        //getters
        public List<string> getAuthors()
        {
            return authors;
        }

        //end of getters

        public void AddAuthor(string name)
        {
            authors.Add(name);
        }

        public DateTime getdate()
        {
            return date;
        }
    }
}
