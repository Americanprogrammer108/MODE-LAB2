﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial2Take2
{

    class Email : Document
    {
        private List<string> to = new List<string>();
        private string subject;

        //constructor

        public Email()
        {

        }

        public Email(List<string> authors, string v)
        {
            to.Add(null);
            this.subject = v;
        }

        //getters
        public string getsubject()
        {
            return subject;
        }

        public List<string> getTo()
        {
            return to;
        }

    }


}
