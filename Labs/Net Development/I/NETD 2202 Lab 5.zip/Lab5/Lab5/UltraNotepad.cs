﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Lab5
{
    public partial class Form1 : Form
    {
        string openFile = String.Empty;
        string filePath = String.Empty;
        public void saveFile(string path)
        {
            memoRichTextBox.SaveFile(path);
        }

        public Form1()
        {
            InitializeComponent();
        }

        //This will save the file at the path indicated by the filename passed in
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (memoRichTextBox.Text != "")
            {
                if (MessageBox.Show("This file hasn't been saved as yet. Save?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Filter = "Text Files (*.txt)|*.txt";


                    if (saveDialog.ShowDialog() == DialogResult.OK)
                    {
                        memoRichTextBox.SaveFile(saveDialog.FileName, RichTextBoxStreamType.PlainText);
                        UpdateTitle();
                    }
                    this.Text = Path.GetFileName(saveDialog.FileName);
                }
                
                Close();
            }
            else
            {

            }


        }

        //This will save the file using the save function
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //If openfile has no value, call Save As instead
            if (openFile == String.Empty)
            {
                saveAsToolStripMenuItem_Click(sender, e);
                
            }
            else
            {
                //If the file exists, update it
                saveFile(openFile);
            }
            
            
        }

        //Open a save dialog and allow the user to pick a location, then save the file
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Text Files (*.txt)|*.txt";
            

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                memoRichTextBox.SaveFile(saveDialog.FileName, RichTextBoxStreamType.PlainText);
                UpdateTitle();
            }
            this.Text = saveDialog.FileName;



        }

        //Creates a new file
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (memoRichTextBox.Text != String.Empty)
            {
                if (MessageBox.Show("Save this file?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    SaveFileDialog saveDialog = new SaveFileDialog();
                    saveDialog.Filter = "Text Files (*.txt)|*.txt";


                    if (saveDialog.ShowDialog() == DialogResult.OK)
                    {
                        memoRichTextBox.SaveFile(saveDialog.FileName, RichTextBoxStreamType.PlainText);
                        UpdateTitle();
                    }
                    this.Text = saveDialog.FileName;
                }
                else
                {
                    memoRichTextBox.Clear();
                    openFile = String.Empty;
                    UpdateTitle();
                }
            }
            else
            {
                memoRichTextBox.Clear();
                openFile = String.Empty;
                UpdateTitle();
            }


        }

        //Opens an existing file
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "open";
            openDialog.Filter = "Text Files (*.txt)|*.txt";
            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                memoRichTextBox.LoadFile(openDialog.FileName, RichTextBoxStreamType.PlainText);
            }
            this.Text = openDialog.FileName;
        }

        //Undos any text highlighted
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            memoRichTextBox.Undo();
        }

        //Redos any text highlighted
        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            memoRichTextBox.Redo();
        }

        //Copies any text highlighted
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            memoRichTextBox.Copy();
        }

        //Pastes any text highlighted
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            memoRichTextBox.Paste();
        }

        //Cuts any text highlighted
        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            memoRichTextBox.Cut();
        }

        //Displays information about the file
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("NETD 2202 " +
                "Lab 5" +
                " By Ethan Chen");
        }

        //Updates the title based on the save function
        private void UpdateTitle()
        {
            this.Text = "Ethan's Notepad";

            if (openFile != String.Empty)
            {
                this.Text += " - " + openFile;
            }
        }

        private void memoRichTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
