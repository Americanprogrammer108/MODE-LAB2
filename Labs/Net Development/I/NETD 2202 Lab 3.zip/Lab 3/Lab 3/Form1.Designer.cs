﻿
namespace Lab_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.caseValue = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.region1List = new System.Windows.Forms.TextBox();
            this.region1 = new System.Windows.Forms.Label();
            this.region3 = new System.Windows.Forms.Label();
            this.region2 = new System.Windows.Forms.Label();
            this.region2List = new System.Windows.Forms.TextBox();
            this.region3List = new System.Windows.Forms.TextBox();
            this.region1Average = new System.Windows.Forms.TextBox();
            this.region3Average = new System.Windows.Forms.TextBox();
            this.region2Average = new System.Windows.Forms.TextBox();
            this.totalAverage = new System.Windows.Forms.TextBox();
            this.enterButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // caseValue
            // 
            this.caseValue.Location = new System.Drawing.Point(54, 17);
            this.caseValue.Margin = new System.Windows.Forms.Padding(2);
            this.caseValue.Name = "caseValue";
            this.caseValue.Size = new System.Drawing.Size(76, 20);
            this.caseValue.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cases:";
            // 
            // region1List
            // 
            this.region1List.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.region1List.Location = new System.Drawing.Point(8, 72);
            this.region1List.Margin = new System.Windows.Forms.Padding(2);
            this.region1List.Multiline = true;
            this.region1List.Name = "region1List";
            this.region1List.ReadOnly = true;
            this.region1List.Size = new System.Drawing.Size(99, 194);
            this.region1List.TabIndex = 5;
            this.region1List.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // region1
            // 
            this.region1.AutoSize = true;
            this.region1.Location = new System.Drawing.Point(33, 57);
            this.region1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.region1.Name = "region1";
            this.region1.Size = new System.Drawing.Size(50, 13);
            this.region1.TabIndex = 1;
            this.region1.Text = "Region 1";
            // 
            // region3
            // 
            this.region3.AutoSize = true;
            this.region3.Location = new System.Drawing.Point(301, 57);
            this.region3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.region3.Name = "region3";
            this.region3.Size = new System.Drawing.Size(50, 13);
            this.region3.TabIndex = 3;
            this.region3.Text = "Region 3";
            // 
            // region2
            // 
            this.region2.AutoSize = true;
            this.region2.Location = new System.Drawing.Point(167, 57);
            this.region2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.region2.Name = "region2";
            this.region2.Size = new System.Drawing.Size(50, 13);
            this.region2.TabIndex = 2;
            this.region2.Text = "Region 2";
            // 
            // region2List
            // 
            this.region2List.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.region2List.Location = new System.Drawing.Point(143, 73);
            this.region2List.Margin = new System.Windows.Forms.Padding(2);
            this.region2List.Multiline = true;
            this.region2List.Name = "region2List";
            this.region2List.ReadOnly = true;
            this.region2List.Size = new System.Drawing.Size(99, 194);
            this.region2List.TabIndex = 5;
            this.region2List.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // region3List
            // 
            this.region3List.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.region3List.Location = new System.Drawing.Point(275, 72);
            this.region3List.Margin = new System.Windows.Forms.Padding(2);
            this.region3List.Multiline = true;
            this.region3List.Name = "region3List";
            this.region3List.ReadOnly = true;
            this.region3List.Size = new System.Drawing.Size(99, 194);
            this.region3List.TabIndex = 5;
            this.region3List.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // region1Average
            // 
            this.region1Average.Location = new System.Drawing.Point(8, 271);
            this.region1Average.Margin = new System.Windows.Forms.Padding(2);
            this.region1Average.Name = "region1Average";
            this.region1Average.ReadOnly = true;
            this.region1Average.Size = new System.Drawing.Size(99, 20);
            this.region1Average.TabIndex = 5;
            this.region1Average.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // region3Average
            // 
            this.region3Average.Location = new System.Drawing.Point(275, 271);
            this.region3Average.Margin = new System.Windows.Forms.Padding(2);
            this.region3Average.Name = "region3Average";
            this.region3Average.ReadOnly = true;
            this.region3Average.Size = new System.Drawing.Size(99, 20);
            this.region3Average.TabIndex = 5;
            this.region3Average.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // region2Average
            // 
            this.region2Average.Location = new System.Drawing.Point(144, 271);
            this.region2Average.Margin = new System.Windows.Forms.Padding(2);
            this.region2Average.Name = "region2Average";
            this.region2Average.ReadOnly = true;
            this.region2Average.Size = new System.Drawing.Size(98, 20);
            this.region2Average.TabIndex = 5;
            this.region2Average.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalAverage
            // 
            this.totalAverage.Location = new System.Drawing.Point(8, 294);
            this.totalAverage.Margin = new System.Windows.Forms.Padding(2);
            this.totalAverage.Name = "totalAverage";
            this.totalAverage.ReadOnly = true;
            this.totalAverage.Size = new System.Drawing.Size(366, 20);
            this.totalAverage.TabIndex = 5;
            this.totalAverage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(8, 337);
            this.enterButton.Margin = new System.Windows.Forms.Padding(2);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(99, 19);
            this.enterButton.TabIndex = 1;
            this.enterButton.Text = "&Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enter_Click);
            // 
            // clearButton
            // 
            this.clearButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearButton.Location = new System.Drawing.Point(143, 337);
            this.clearButton.Margin = new System.Windows.Forms.Padding(2);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(99, 19);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "&Reset";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.reset_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(275, 337);
            this.exitButton.Margin = new System.Windows.Forms.Padding(2);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(99, 19);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "&Quit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exit_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.enterButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearButton;
            this.ClientSize = new System.Drawing.Size(385, 366);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.totalAverage);
            this.Controls.Add(this.region2Average);
            this.Controls.Add(this.region3Average);
            this.Controls.Add(this.region1Average);
            this.Controls.Add(this.region3List);
            this.Controls.Add(this.region2List);
            this.Controls.Add(this.region2);
            this.Controls.Add(this.region3);
            this.Controls.Add(this.region1);
            this.Controls.Add(this.region1List);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.caseValue);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Average Weekly Units by Region";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox caseValue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox region1List;
        private System.Windows.Forms.Label region1;
        private System.Windows.Forms.Label region3;
        private System.Windows.Forms.Label region2;
        private System.Windows.Forms.TextBox region2List;
        private System.Windows.Forms.TextBox region3List;
        private System.Windows.Forms.TextBox region1Average;
        private System.Windows.Forms.TextBox region3Average;
        private System.Windows.Forms.TextBox region2Average;
        private System.Windows.Forms.TextBox totalAverage;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

