﻿// Author: Ethan Chen
// Created: February 19, 2022
// Modified: March 5, 2022 at 10:32PM
// Description: This form takes 21 inputs (7 per region) from the user and calculates a set of averages of 3 regions. When all 21 inputs have been accepted as valid
// whiole numbers, an overall average is displayed. Functionality to reset the form is RESET. NOTE: I have done the bonus, so it'll display if the averages are red
// or green based on the overall average of that region.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3
{
    public partial class Form1 : Form
    {
        
        
        //All declarations
        
        
        //Declare the number of regions and number of days
        const int maximumUnits = 5000;
        const int maximumDays = 7;
        const int maximumRegions = 3;

        //Declare an array to contain all of the inputs
        int[,] units = new int[maximumRegions, maximumDays]; // units [3,7]
        int myRegion;
        float region1Total, region2Total, region3Total;

        int day;
        float regionAverage1, regionAverage2, regionAverage3, overallAverage;
        int i = 0; //this is to count the number of days in a specific region


        //End of declarations

        public Form1()
        {
            InitializeComponent();
        }

        //Set the form back to its default state, including focus, class-level variables and controls.
        public void SetDefaults()
        {

        }

        private void reset_Click(object sender, EventArgs e) //Clear everything
        {
            //It erases everything including data in the array
            caseValue.Clear();
            region1List.Clear();
            region2List.Clear();
            region3List.Clear();

            region1Average.Clear();
            region2Average.Clear();
            region3Average.Clear();
            totalAverage.Clear();

            caseValue.Enabled = true;
            enterButton.Enabled = true;
            
            
            day = 0;
            myRegion = 0;
            region1Total = 0;
            region2Total = 0;
            region3Total = 0;
            
            enterButton.Focus();

            regionAverage1 = 0;
            regionAverage2 = 0;
            regionAverage3 = 0;
            i = 0;
            caseValue.Focus();

            //Color is set to light gray as default
            region1Average.BackColor = Color.LightGray;
            region2Average.BackColor = Color.LightGray;
            region3Average.BackColor = Color.LightGray;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            //Close the program
            Close();
        }



        private void enter_Click(object sender, EventArgs e)
        {
            //what happens if I press the ENTER button or hit ENTER?
            
            if (int.TryParse(caseValue.Text, out int myValue))
            {
                if (myRegion == 0) //region 1
                {
                    //region1Font.Bold = true; fix 
                    if (day == maximumDays-1) // if (6 == 6) also known as the 7th day, should you add the value to the 7th day?
                    {
                        units[myRegion, day] = myValue;
                        //region1Total += myValue;
                        region1List.Text += myValue + "\r\n";
                        while (i < 7)
                        {
                        //the for loop didn't work, so the while loop fixed it
                            region1Total += units[myRegion, i];
                            i++;
                        }
                        regionAverage1 = (region1Total / 7);
                        region1Average.Text = "Average: " + Math.Round(regionAverage1, 2);
                        caseValue.Clear();
                        myRegion++;
                        day = 0;
                        i = 0;
                    }
                    else
                    {
                        if (myValue > maximumUnits || myValue < 0)
                        {
                            MessageBox.Show("Range must be between 0 and " + maximumUnits + "!");
                            caseValue.Focus();
                        }
                        else
                        {
                            units[myRegion, day] = myValue; 
                            region1List.Text += myValue + "\r\n";
                            day++;
                            caseValue.Clear();
                        }

                    }


                }
                else if (myRegion == 1) //region 2
                {
                    if (day == maximumDays-1)
                    {
                        units[myRegion, day] = myValue;
                        caseValue.Clear();
                        region2List.Text += myValue + "\r\n";
                        while (i < 7)
                        {
                            region2Total += units[myRegion, i];
                            i++;
                        }
                        regionAverage2 = region2Total / 7;
                        region2Average.Text = "Average: " + Math.Round(regionAverage2, 2);
                        myRegion++;
                        day = 0;
                        i = 0;

                        if (regionAverage2 > regionAverage1)
                        {
                            region2Average.BackColor = Color.Red;
                        }
                        else if (regionAverage2 < regionAverage1)
                        {
                            region2Average.BackColor = Color.Green;
                        }
                    }
                    else
                    {
                        if (myValue > maximumUnits || myValue < 0)
                        {
                            MessageBox.Show("Range must be between 0 and " + maximumUnits + "!");
                        }
                        else
                        {
                            units[myRegion, day] = myValue;
                            region2List.Text += myValue + "\r\n";
                            day++;
                            caseValue.Clear();

                        }

                    }
                }
                else if (myRegion == 2) //region 3
                {
                    if (day == maximumDays - 1)
                    {
                        units[myRegion, day] = myValue;
                        caseValue.Clear();
                        region3List.Text += myValue + "\r\n";
                        while (i < 7)
                        {
                            region3Total += units[myRegion, i];
                            i++;
                        }
                        regionAverage3 = region3Total / 7;
                        region3Average.Text = "Average: " + Math.Round(regionAverage3, 2);
                        if (regionAverage3 > regionAverage2)
                        {
                            region3Average.BackColor = Color.Red;
                        }
                        else if (regionAverage3 < regionAverage2)
                        {
                            region3Average.BackColor = Color.Green;
                        }

                        //display the total average
                        overallAverage = (regionAverage1 + regionAverage2 + regionAverage3) / 3;
                        totalAverage.Text = "The total average for this week is " + Math.Round(overallAverage, 2);

                        caseValue.Enabled = false;
                        enterButton.Enabled = false;
                        clearButton.Focus();

                    }
                    else
                    {
                        if (myValue > maximumUnits || myValue < 0)
                        {
                            MessageBox.Show("Range must be between 0 and " + maximumUnits + "!");
                        }
                        else
                        {
                            units[myRegion, day] = myValue;
                            region3List.Text += myValue + "\r\n";
                            day++;
                            caseValue.Clear();
                        }


                    }
                }
            }
            else
            {
                MessageBox.Show("This is not a valid input!");
                enterButton.Focus();
                caseValue.Focus();
            }    

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //What happens when the form loads?
            day = 0;
            myRegion = 0;
            region1Total = 0;
            region2Total = 0;
            region3Total = 0;
           
            regionAverage1 = 0;
            regionAverage2 = 0;
            regionAverage3 = 0;

            //Not automatically sized
            region1List.AutoSize = false;
            region2List.AutoSize = false;
            region3List.AutoSize = false;

            region1Average.AutoSize = false;
            region2Average.AutoSize = false;
            region3Average.AutoSize = false;


            //All tooltips

            //buttons
            ToolTip enterVal = new ToolTip();
            ToolTip exitProgram = new ToolTip();
            ToolTip eraseEverything = new ToolTip();
            enterVal.SetToolTip(enterButton, "Appends the value. If full, it is disabled.");
            exitProgram.SetToolTip(exitButton, "Exits the program");
            eraseEverything.SetToolTip(clearButton, "Clears everything, including the region's data");

            region1Average.BackColor = Color.LightGray;
            region2Average.BackColor = Color.LightGray;
            region3Average.BackColor = Color.LightGray;

            //read-only textboxes

            //input text
            ToolTip inputValue = new ToolTip();
            inputValue.SetToolTip(caseValue, "Please enter a numeric value between 0 and " + maximumUnits);


            //region 1
            ToolTip region1Content = new ToolTip();
            region1Content.SetToolTip(region1List, "This is region 1's content");

            ToolTip region1TotalAverage = new ToolTip();
            region1TotalAverage.SetToolTip(region1Average, "Displays region 1's average after 7 days have been appended");


            //region 2
            ToolTip region2Content = new ToolTip();
            region2Content.SetToolTip(region2List, "This is region 2's content");

            ToolTip region2TotalAverage = new ToolTip();
            region2TotalAverage.SetToolTip(region2Average, "Displays region 2's average after 7 days have been appended");


            //region 3
            ToolTip region3Content = new ToolTip();
            region3Content.SetToolTip(region3List, "This is region 3's content");

            ToolTip region3TotalAverage = new ToolTip();
            region3TotalAverage.SetToolTip(region3Average, "Displays region 3's average after 7 days have been appended");

            //Average box
            ToolTip overallTotalAverage = new ToolTip();
            overallTotalAverage.SetToolTip(totalAverage, "This displays the average of the 3 regions after their averages have been calculated");


            //Case value
            ToolTip caseVal = new ToolTip();
            caseVal.SetToolTip(label1, "Enter the number of units");
        }


    }
}
