﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab_4.MODELS
{
    public class textbook
    {
        public string textbook_title { get; set; }
        public int textbook_ISBN { get; set; }
        public string textbook_version { get; set; }
        public int textbook_price { get; set; }

        public string textbook_condition { get; set; }


        public textbook()
        {

        }

        public textbook(string make, int ISBN, string textbookversion, int price, string condition)
        {
            this.textbook_title = make;
            this.textbook_ISBN = ISBN;
            this.textbook_version = textbookversion;
            this.textbook_price = price;
            this.textbook_condition = condition;
        }

        public double Calculate(string condition, int textbookprice)
        {
            double result = 0;
            if (condition == "Bad")
            {
                result = textbook_price / 4;
            }
            else if (condition == "Good")
            {
                result = textbook_price / 3;
            }
            else if (condition == "New")
            {
                result = textbook_price / 2;
            }

            return result;
        }


        public override string ToString()
        {
            return "Your textbook: " + this.textbook_title + " ISBN: " + this.textbook_ISBN + " Textbook version: " + this.textbook_version + " Price: $" + this.textbook_price; 
        }
    }
}
