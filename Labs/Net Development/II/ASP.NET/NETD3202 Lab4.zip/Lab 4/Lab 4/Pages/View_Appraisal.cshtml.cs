using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab_4.Pages
{
    public class View_AppraisalModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
