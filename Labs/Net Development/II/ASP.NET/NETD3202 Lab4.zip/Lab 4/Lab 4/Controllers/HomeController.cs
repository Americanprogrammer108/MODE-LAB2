﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Lab_4.MODELS;

namespace Lab_4.Controllers
{
    public class HomeController : Controller
    {
        public List<textbook> listoftextbooks = new List<textbook>();
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Appraise()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Appraise(textbook model)
        {
            string message = "";

            if (ModelState.IsValid)
            {
                ViewData["Message"] = "Textbook Title: " + model.textbook_title + "\n ISBN: " + model.textbook_ISBN + "\nVersion: " + model.textbook_version + "\nPrice: $" + model.textbook_price;
                ViewData["Appraise"] = "This textbook is valued at: $" + model.Calculate(model.textbook_condition, model.textbook_price);

                listoftextbooks.Add(new textbook(model.textbook_title, model.textbook_ISBN, model.textbook_version, model.textbook_price, model.textbook_condition));
                return View("Appraised", model);
            }
            else
            {
                ViewData["AppraisalFailed"] = "404 ERROR: Appraisal Failed :(";
                message = "AppraisalFailed";
                return View(message);
            } 
        }


    }
}
