using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace WebApplication2.Pages.CarModels
{
    public class AllModelsModel : PageModel
    {
        public List<ModelInfo> allNissanModels = new List<ModelInfo>();
        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=.\\LAPTOP-E8H3L8KS;Initial Catalog=Users;Integrated Security=True";
                using (SqlConnection myconnection = new SqlConnection(connectionString))
                {
                    //Open the database
                    myconnection.Open();
                    string mysql = "SELECT * FROM NissanCarModelTable";
                    
                    //this will allow the user to view all models of all Nissan cars
                    using (SqlCommand mycommand = new SqlCommand(mysql, myconnection))
                    {
                        using (SqlDataReader myreader = mycommand.ExecuteReader())
                        {
                            while (myreader.Read())
                            {
                                ModelInfo modelInfo = new ModelInfo();
                                modelInfo.model = myreader.GetString(0);
                                modelInfo.year = myreader.GetInt32(1);
                                modelInfo.price = myreader.GetDouble(2);
                                modelInfo.distance = myreader.GetInt32(3);
                                modelInfo.condition = myreader.GetString(4);
                                modelInfo.type = myreader.GetString(5);

                                allNissanModels.Add(modelInfo);
                            }
                        }
                    }
                   myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }

    public class ModelInfo
    {
        public string model, condition, type;
        public int year, distance;
        public double price;
    }
}
