using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace WebApplication2.Pages.CarModels
{
    public class AddModelModel : PageModel
    {
        public ModelInfo Modelinfo = new ModelInfo();
        public string errorMessage = "";
        public string successMessage = "";
        public void OnGet()
        {

        }

        public void OnPost()
        {
            string ff = Request.Form["year"];

            Modelinfo.model = Request.Form["model"];
            Modelinfo.price = Convert.ToDouble(Request.Form["price"]);
            Modelinfo.condition = Request.Form["condition"];
            Modelinfo.type = Request.Form["type"];

            //validate int and float values
            if (int.TryParse(Request.Form["year"], out int yearvalue))
            {
                Modelinfo.year = yearvalue;
            }            
            
            if (int.TryParse(Request.Form["distance"], out int distancevalue))
            {
                Modelinfo.distance = distancevalue;
            }            
            




            if (Modelinfo.model == "" || Modelinfo.year == 0 || Modelinfo.price == 0 || Modelinfo.distance == 0 || Modelinfo.condition == null || Modelinfo.type == null)
            {
                errorMessage = "All fields are required";
                return;
            }

            try
            {
                string connectionString = "Data Source=LAPTOP-E8H3L8KS;Initial Catalog=Users;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    //Open the connection
                    connection.Open();
                    string sqladd = "INSERT INTO NissanCarModelTable VALUES (@model, @year, @price, @distance, @condition, @type)";
                    using (SqlCommand command = new SqlCommand(sqladd, connection))
                    {
                        command.Parameters.AddWithValue("@model", Modelinfo.model);
                        command.Parameters.AddWithValue("@year", Modelinfo.year);
                        command.Parameters.AddWithValue("@price", Modelinfo.price);
                        command.Parameters.AddWithValue("@distance", Modelinfo.distance);
                        command.Parameters.AddWithValue("@condition", Modelinfo.condition);
                        command.Parameters.AddWithValue("@type", Modelinfo.type);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            Modelinfo.model = "";
            Modelinfo.year = 0;
            Modelinfo.price = 0;
            Modelinfo.distance = 0;
            Modelinfo.condition = "";
            Modelinfo.type = "";
        }
    }
}
