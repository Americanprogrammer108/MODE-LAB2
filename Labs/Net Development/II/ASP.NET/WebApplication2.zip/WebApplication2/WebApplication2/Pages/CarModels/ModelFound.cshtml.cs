using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Copy_of_Final_Lab_for_NETD3202.Pages.CarModels
{
    public class ModelFoundModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
