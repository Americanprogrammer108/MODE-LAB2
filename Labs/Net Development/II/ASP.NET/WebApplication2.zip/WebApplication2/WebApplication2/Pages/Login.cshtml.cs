using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.Common;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using WebApplication2.Pages.CarModels;
using static Copy_of_Final_Lab_for_NETD3202.Pages.OwnerCarInfoModel;

namespace Copy_of_Final_Lab_for_NETD3202.Pages
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {


        }

        public void OnPost()
        {
            string connectionString = "Data Source=LAPTOP-E8H3L8KS;Initial Catalog=Users;Integrated Security=True";
            using (SqlConnection myconnection = new SqlConnection(connectionString))
            {
                //Open the database
                myconnection.Open();
                string mysql = "SELECT * FROM RegisteredUsersTable WHERE FirstName = '" + Request.Form["firstname"] + "'";

                //this will allow the user to view all models of all Nissan cars
                using (SqlCommand mycommand = new SqlCommand(mysql, myconnection))
                {
                    using (SqlDataReader myreader = mycommand.ExecuteReader())
                    {
                        while (myreader.Read())
                        {
                            OwnerCarInfo ownerCarInfo = new OwnerCarInfo();
                            ownerCarInfo.firstname = myreader.GetString(0);
                            ownerCarInfo.lastname = myreader.GetString(1);

                        }
                    }
                }
                myconnection.Close();
            }
            string login = "yes";
            
        }
    }
}
