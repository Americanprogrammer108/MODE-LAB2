using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using WebApplication2.Pages.CarModels;

namespace Copy_of_Final_Lab_for_NETD3202.Pages
{
    public class OwnerCarInfoModel : PageModel
    {
        public List<OwnerCarInfo> ownerCarInfo = new List<OwnerCarInfo>();
        public void OnGet()
        {
            string firstname, lastname;
            /* 
            firstname = Request.Form["FirstName"];
            lastname = Request.Form["LastName"];
            try
            {
                string connectionString = "Data Source=LAPTOP-E8H3L8KS;Initial Catalog=Users;Integrated Security=True";
                using (SqlConnection myconnection = new SqlConnection(connectionString))
                {
                    //Open the database
                    myconnection.Open();
                    string mysql = "SELECT * FROM RegisteredUsersTable WHERE FirstName = '" + firstname +"' AND LastName = '" + lastname;

                    SqlCommand mycommand = new SqlCommand(mysql, myconnection);

                    mycommand.ExecuteNonQuery();

                    Console.WriteLine(mycommand.ExecuteNonQuery());
                    Console.ReadLine();
                    if (mycommand.ExecuteNonQuery() >= 0)
                    {
                        
                        //redirect to the modelfound page
                        
                    }
                    else
                    {
                        //redirect user to say that the model is not found
                        
                    }

                    //this will allow the user to view all models of all Nissan cars
                    /* 
                    using (SqlCommand mycommand = new SqlCommand(mysql, myconnection))
                    {
                        using (SqlDataReader myreader = mycommand.ExecuteReader())
                        {
                            while (myreader.Read())
                            {
                                OwnerCarInfo ownerCarinfo = new OwnerCarInfo();
                                ownerCarinfo.firstname = myreader.GetString(0);
                                ownerCarinfo.lastname = myreader.GetString(1);
                                ownerCarinfo.model = myreader.GetString(2);
                                ownerCarinfo.price = myreader.GetFloat(3);
                                ownerCarinfo.date = myreader.GetDateTime(4).ToString();

                                ownerCarInfo.Add(ownerCarinfo);
                            }
                        }
                    } 


                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            } */
        }

        public class OwnerCarInfo
        {
            public string firstname, lastname, model, date;
            public double price;
        }
    }
}
