using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Pages
{
    public class SignOutModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
