using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.Common;
using System.Data.SqlClient;

namespace WebApplication2.Pages.CarModels
{
    public class FindModelModel : PageModel
    {
        public SqlCommand mycommand = new SqlCommand();

        public ModelInfo Modelinfo = new ModelInfo();
        public void OnGet()
        {
        }

        public void OnPost()
        {
            //let's start off with string values
            string model = Request.Form["model"];
            string year = Request.Form["year"];
            string price = Request.Form["price"];
            string distance = Request.Form["distance"];

            //if year or distance values are ints, convert
            if (int.TryParse(Request.Form["year"], out int yearvalue))
            {
                Modelinfo.year = yearvalue;
            }

            if (int.TryParse(Request.Form["distance"], out int distancevalue))
            {
                Modelinfo.distance = distancevalue;
            }

            //display table to find the model
            SqlConnection myconnection = new SqlConnection("Data Source=LAPTOP-E8H3L8KS;Initial Catalog=Users;Integrated Security=True");
            
            //open the database
            myconnection.Open();
            string mysql = "SELECT * FROM NissanCarModelTable WHERE Model = '" + model + "'";

            SqlCommand mycommand = new SqlCommand(mysql, myconnection);
            
            mycommand.ExecuteNonQuery();
            Console.WriteLine(mycommand.ExecuteNonQuery());
           

            if (mycommand.ExecuteNonQuery() >= 0)
            {
                //redirect to the modelfound page
                Response.Redirect("ModelFound");
            }
            else
            {
                //redirect user to say that the model is not found
                Response.Redirect("ModelNOTFound");
            }
            myconnection.Close();
        }
    }
}
