﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NETD3202_Lab1
{
    public class Program
    {
        //First private data member
        private string projectName;
        //Complete the rest (there are four more mentioned in the description).
        //constructor, you need to complete it this is a no parameter constructor 
        //shown below.
        
        public Program()
        {

        }
        //Getters and Setters for each private data member go below.
        /*This one is an example, notice that the data member is called private 
        string “projectName” the getter/setter property is named 
        “ProjectName”(different capitalization).*/
        public string ProjectName
        {
            get { return this.projectName; }
            set { this.projectName = value; }

        }
    }
}
