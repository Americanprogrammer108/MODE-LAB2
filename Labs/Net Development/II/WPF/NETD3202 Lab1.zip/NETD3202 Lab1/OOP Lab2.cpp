#include <iostream>
#include "Ticket.h"
using namespace std;
int main() {
	Ticket airCanada[] = {
	Ticket("Olilvia Williams"),
	Ticket(549, 34,false,"x057829","Emma Miles", "ParisFrance-DubaiUAE"),
	Ticket(349, 24,false,"a457829","Owen Theodore", "LondonUK-TorontoCanada"),
	Ticket(749, 54,true,"x157829","Jacob Mason", "TokyoJapan-EdmontonCanada"),
	Ticket(1549, 21,false,"x657829","", "ManchesterUK-LondonCanada"),
	Ticket(849, 34,false,"x757829",nullptr, "ManchesterUK-LondonCanada"),
	Ticket(549, 84,false,"x857829","David James", ""),
	Ticket(449, 94,false,"x857829","David James", nullptr),
	Ticket(1149, 14,false,"x300509","Sara Noah", "DenverUSA-SydneyAustralia"),
	Ticket(1119, 10,false,"x366509","Jackson Liam", "CairoEgypt-LondonUK"),
	Ticket(849, 224,false,nullptr,"Mikr James", "AthensGreece-LondonCanada"),
	};
	cout << "********************** Iteration #1 **********************" << endl;
	for (unsigned int count = 0; count < 10; count++)
		airCanada[count].display();
	cout << "********************** Iteration #2 **********************" << endl;
	airCanada[1] = "DubaiUAE-ChicagoUSA";
	airCanada[2] = "DubaiUAE-ChicagoUSA";
	airCanada[3] = "DubaiUAE-ChicagoUSA";
	cout << " Test " << endl;
	for (unsigned int count = 0; count < 10; count++)
		airCanada[count].display();

	cout << "********************** Iteration #3 **********************" << endl;
	airCanada[0] << airCanada[1];
	airCanada[10] << airCanada[8];
	for (unsigned int count = 0; count < 10; count++)
		airCanada[count].display();
	return 0;
}