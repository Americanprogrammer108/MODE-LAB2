﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NETD3202_Lab1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int selectedIndex = -1;
        int projectcount = 0;
        class Project
        {
            string projectName;
            decimal budget;
            decimal amountSpent;
            int hoursRemaining;
            string projectStatus;
            int projectcount = 1;
            private object listProjectName;
            private decimal[] listBudget;
            private decimal[] listAmountSpent;
            private int[] listHoursRemaining;
            private string[] listProjectStatus;

            public Project(string projectName, decimal budget, decimal amountSpent, int hoursRemaining, string projectStatus)
            {
                this.projectName = projectName;
                this.budget = budget;
                this.amountSpent = amountSpent;
                this.hoursRemaining = hoursRemaining;
                this.projectStatus = projectStatus;


                projectcount++;
                /* */

                
                listProjectName = new string[] { projectName };
                listBudget = new decimal[] { budget };
                listAmountSpent = new decimal[] { amountSpent };
                listHoursRemaining = new int[] { hoursRemaining };
                listProjectStatus = new string[] { projectStatus };

                //listProjectName.Append(projectName);
                listBudget.Append(budget);
                listAmountSpent.Append(amountSpent);
                listHoursRemaining.Append(hoursRemaining);
                listProjectStatus.Append(projectStatus);

                //listBudget[projectcount] = this.budget;
            }

            public Project(string projectName, decimal budget, decimal amountSpent, int hoursRemaining, string projectStatus, int selectedIndex) : this(projectName, budget, amountSpent, hoursRemaining, projectStatus)
            {
                SelectedIndex = selectedIndex;
            }

            public Project(string projectName, decimal budget, decimal amountSpent, int hoursRemaining, string projectStatus, int selectedIndex, Project project) //this will retrieve information based on the selected project
            {
                MessageBox.Show("Project: " + project.projectName + "\n Project Budget: " + budget + "\n Amount spent: " + amountSpent + "\n Hours Remaining: " + hoursRemaining + "\nStatus: " + projectStatus, "Receipt:");
            }


            public int SelectedIndex { get; }
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            decimal projectbudget = 0;
            decimal spentbudget = 0;
            int hoursRemaining = 0;

            //Go through validation
            if (ProjectName.Text == "" || ProjectBudget.Text == "" || BudgetSpent.Text == "" || RemainingHrs.Text == "" || !Decimal.TryParse(ProjectBudget.Text, out projectbudget) || !Decimal.TryParse(BudgetSpent.Text, out spentbudget) || !int.TryParse(RemainingHrs.Text, out hoursRemaining))
            {
                Errormessages.Clear();

                if (ProjectName.Text == "")
                {
                    Errormessages.AppendText("Please type the project name!\n");
                }

                if (ProjectBudget.Text == "")
                {
                    Errormessages.AppendText("Please enter the project budget!\n");
                }
                else if (Decimal.TryParse(ProjectBudget.Text, out projectbudget))
                {
                    if (projectbudget < 0)
                    {
                        Errormessages.AppendText("The budget cannot be negative!\n");
                    }
                }
                else if (!Decimal.TryParse(ProjectBudget.Text, out projectbudget))
                {
                    Errormessages.AppendText("The budget cannot be non-numeric!\n");
                }

                if (BudgetSpent.Text == "")
                {
                    Errormessages.AppendText("Budget spent is not entered!\n");
                }
                else if (Decimal.TryParse(BudgetSpent.Text, out spentbudget))
                {
                    if (spentbudget < 0)
                    {
                        Errormessages.AppendText("Budget cannot be negative!\n");
                    }

                }
                else if (!Decimal.TryParse(BudgetSpent.Text, out spentbudget))
                {
                    Errormessages.AppendText("The spent budget cannot be non-numeric!\n");
                }

                if (RemainingHrs.Text == "")
                {
                    Errormessages.AppendText("Please enter the remaining hours!\n");
                }
                else if (hoursRemaining < 0)
                {
                    Errormessages.AppendText("The number of hours cannot be negative!\n");
                }
                else if (!int.TryParse(RemainingHrs.Text, out hoursRemaining))
                {
                    Errormessages.AppendText("Remaining hours cannot be non-numeric!");
                }
            }
            else
            {
                Project newproject = new Project(ProjectName.Text, projectbudget, spentbudget, hoursRemaining, StatusUpdate.Text);
                projectlist.Items.Add(ProjectName.Text);
                
                projectcount++;
                
                ProjectName.Text = "";
                ProjectBudget.Text = "";
                BudgetSpent.Text = "";
                RemainingHrs.Text = "";

            }



            //Create a class called Project

        }

        private void StatusUpdate_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StatusUpdate.Text == "Complete")
            {
                RemainingHrs.Text = "0";
            }
        }

        private void projectlistClick(object sender, MouseButtonEventArgs e)
        {

            selectedIndex = projectlist.SelectedIndex;

            //selectedIndex = projectlist.ItemsSource;
            getproject.Text = "Project" + selectedIndex;
            //MessageBox.Show();
            //projectlist.Items[selectedIndex];
        }

        private void listBoxClick(object sender, MouseButtonEventArgs e)
        {
            decimal displaybudget, displayspent;
            int displayhours;

            //displayhours = Project listProjectHours;
            int.TryParse(RemainingHrs.Text, out displayhours);
            Decimal.TryParse(ProjectBudget.Text, out displaybudget);
            Decimal.TryParse(BudgetSpent.Text, out displayspent);

            Project displayproject = new Project(ProjectName.Text, displaybudget, displayspent, displayhours, StatusUpdate.Text, selectedIndex);
            //string details = "Project Name: " + ProjectName.Text + " \n";
            //MessageBox.Show(details, "Project Details");
        }
    }
}