class Ticket
{
    //All of this is private
    char* m_passengerName;
    char* m_route;
    char* m_ticketNum;
    double m_allowance;
    double m_fares;
    bool m_restricted;


    //Functions
    void setToDefault(double fares, double allowance, bool restricted, const char* ticketNum =
        nullptr, const char* passengerName = nullptr, const char* route = nullptr)
    {
        m_passengerName == passengerName;
        m_fares = fares;
        m_allowance = allowance;
        m_restricted = restricted;
        m_ticketNum = "";
        m_route = "";
    }

    void setName(char* passengerName)
    {
        m_passengerName = passengerName;
    }

    void setRoute(char* route)
    {
        m_route = route;
    }

    void setTicketNum(char* ticketNum)
    {
        m_ticketNum = ticketNum;
    }

    //done
    bool isRestricted()const; //
    void cancel();
public:
    Ticket()
    {
        setToDefault();
    }

    Ticket(const char* passengerName); //done constructor 1
    Ticket(double fares, double allowance, bool restricted, const char* ticketNum =
        nullptr, const char* passengerName = nullptr, const char* route = nullptr)
    {
        setToDefault();
        if (passengerName != nullptr && *passengerName != '\0' && route != nullptr && *route != '\0'
            && ticketNum != nullptr && *ticketNum == 'x' && allowance <= 35) //Using pounds instead of kilograms
        {
            m_fares = fares;
            m_allowance = allowance;
            m_restricted = restricted;
            setName(passengerName);
            setRoute(route);
            setTicketNum(ticketNum);
        }
    } //done
    ~Ticket(); //done
    bool isValid()const
    {
        if (passengerName != nullptr && *passengerName != '\0')
        {
            setName(passengerName);
        }
    }
    Ticket& operator=(const char* route);
    Ticket& operator<<(Ticket&); //done
    std::ostream& display()const; //done
};
