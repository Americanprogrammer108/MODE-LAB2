#include <iostream>
#include "Ticket.h"
using namespace std;


namespace sdds
{

    Ticket()
    {
        setToDefault();
    }

    Ticket(passengerName)
    {
        Ticket::setToDefault();
        if (passengerName != nullptr && *passengerName != '\0')
        {
            setName(passengerName);
        }
    }

    Ticket(fares, allowance, restricted, ticketNum, passengerName, route)
    {
        setToDefault();
        if (passengerName != nullptr && *passengerName != '\0' && route != nullptr && *route != '\0'
            && ticketNum != nullptr && *ticketNum == 'x' && allowance <= 35) //Using pounds instead of kilograms
        {
            m_fares = fares;
            m_allowance = allowance;
            m_restricted = restricted;
            setName(passengerName);
            setRoute(route);
            setTicketNum(ticketNum);
        }
    }

    ~Ticket()
    {
        //Make sure there is no memory leak
        /* */
        int* ptr = new int(ticketNum);
        delete (ptr);

    }

    Ticket.isValid()const
    {
        if (m_passengerName != nullptr)
        {
            return true;
        }
        else
        {
            return false;
        }
    }


    std::ostream& display()
    {
        if (Ticket isValid(false))
        {
            cout << "-----INVALID-----";
        }

        if (Ticket setRoute == nullptr)
        {
            cout << "[Route]-----No Route Registered-----";
        }

        if (Ticket setTicketNum == nullptr)
        {
            cout << "-----No TicketNum Registered-----";
        }
    }

    Ticket Ticket& operator<<(Ticket&) //::Ticket& operator<<(Ticket&)
    {
        if (m_restricted == false && fare < allowance)
        {

        }
    }

    Ticket& operator=(route)
    {
        if (m_restricted == false && isValid == true)
        {

        }
        setRoute();
    }
}
