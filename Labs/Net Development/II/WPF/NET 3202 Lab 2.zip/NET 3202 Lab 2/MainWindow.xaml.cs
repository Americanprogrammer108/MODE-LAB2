﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace NET_3202_Lab_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        
        public const string phoneNumber = @"^(^[0][1-9]\d{8}$)+$";
        
        public int random()
        {
            Random randomint = new Random();
            int number = randomint.Next();
            return number;
        }

        private void GetEmployeeData()
        {
            InitializeComponent();
            FillTable();
        }

        private void FillTable()
        {
            try
            {
                //again, connect to database
                string dbConnect = Properties.Settings.Default.db_connect; 
                
                //create a new connection, then open the database
                SqlConnection connectdatabase = new SqlConnection(dbConnect);

                connectdatabase.Open();

                string getDetails = "SELECT * FROM EmployeeDetails";

                //Run the query
                SqlCommand infocommand = new SqlCommand(getDetails, connectdatabase);

                //Use an SqlDataAdapter
                SqlDataAdapter db_adapter = new SqlDataAdapter(infocommand);

                DataTable db_table = new DataTable("EmployeeDetails");

                //This will fill the table with the employees information
                db_adapter.Fill(db_table);
                InformationDisplay.ItemsSource = db_table.DefaultView;

                connectdatabase.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }
        /* private void addEmployeetoDatabase(object sender, RoutedEventArgs e)
        {
            try
            {
                //
                string dbconnect = Properties.Settings.Default.db_connect;
                SqlConnection con = new SqlConnection(dbconnect);

                con.Open();

                int ID = random();

                string insertStatement = "INSERT INTO EmployeeDetails (Id, FullName, EquipmentDes, PhoneNo) VALUES ('" + "')";
            }
            catch ()
            {

            }
        } */
        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ErrorMessages.Clear();

            if (NameBox.Text == "" || EmployeeBox.Text == "" || DescriptionBox.Text == "" || PhoneNumberBox.Text == "" || !int.TryParse(EmployeeBox.Text, out int employeeid)) // || !int.TryParse(PhoneNumberBox.Text, out int phoneNumbertext))
            {
                if (NameBox.Text == "")
                {
                    ErrorMessages.AppendText("Please enter a name!");
                }
                else if (int.TryParse(NameBox.Text, out int numericname))
                {
                    ErrorMessages.AppendText("Name cannot be numeric!");
                }
                
                if (EmployeeBox.Text == "")
                {
                    ErrorMessages.AppendText("\nPlease enter the ID of the employee!");
                }
                else if (!int.TryParse(EmployeeBox.Text, out employeeid) )
                {
                        ErrorMessages.AppendText("\nEmployee ID cannot be a string!");
                }
                

                if (DescriptionBox.Text == "")
                {
                    ErrorMessages.AppendText("\nPlease enter the description!");
                }
                
                Regex regex = new Regex(@"^(^[0][1-9]\d{8}$)+$");
                Match match = regex.Match(phoneNumber);

                if (PhoneNumberBox.Text == "")
                {
                    ErrorMessages.AppendText("\nPlease enter a phone number!");
                }
                else if (!match.Success)
                {
                        ErrorMessages.AppendText("\nInvalid phone number!");
                }
               
            }
            else
            {
                //add details to database
                try
                {
                    //
                    string dbconnect = Properties.Settings.Default.db_connect;
                    SqlConnection con = new SqlConnection(dbconnect);

                    //open the database
                    con.Open();

                    int ID = random();

                    //insert statements after validating information in the textboxes
                    string insertStatement = "INSERT INTO EmployeeDetails (Id, FullName, EquipmentDes, PhoneNo) VALUES ('" + employeeid + "', '" + NameBox.Text + "', '" + DescriptionBox.Text + "', '" + PhoneNumberBox.Text + "')";
                    SqlCommand command = new SqlCommand(insertStatement, con);
                    
                    //execute the command before closing the database
                    command.ExecuteNonQuery();
                    con.Close();

                    NameBox.Text = "";
                    EmployeeBox.Text = "";
                    DescriptionBox.Text = "";
                    PhoneNumberBox.Text = "";
                    MessageBox.Show("Employee details added");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //hide all the elements from the second button
            TitleofContent2.Visibility = Visibility.Hidden;
            InformationDisplay.Visibility = Visibility.Hidden;

            //Then show all the elements from the first one
            Namelabel.Visibility = Visibility.Visible;
            NameBox.Visibility = Visibility.Visible;

            EmployeeIDlabel.Visibility = Visibility.Visible;
            EmployeeBox.Visibility = Visibility.Visible;

            Equipmentdescriptionlabel.Visibility = Visibility.Visible;
            DescriptionBox.Visibility = Visibility.Visible;

            Phonenumberlabel.Visibility = Visibility.Visible;
            PhoneNumberBox.Visibility = Visibility.Visible;

            ErrorMessages.Visibility = Visibility.Visible;

            AddEmployee.Visibility = Visibility.Visible;

            TitleofContent.Visibility = Visibility.Visible;

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            //upon clicking the button, hide all elements
            
            Namelabel.Visibility = Visibility.Hidden;
            NameBox.Visibility = Visibility.Hidden;

            EmployeeIDlabel.Visibility = Visibility.Hidden;
            EmployeeBox.Visibility = Visibility.Hidden;

            Equipmentdescriptionlabel.Visibility = Visibility.Hidden;
            DescriptionBox.Visibility = Visibility.Hidden;

            Phonenumberlabel.Visibility = Visibility.Hidden;
            PhoneNumberBox.Visibility = Visibility.Hidden;

            ErrorMessages.Visibility = Visibility.Hidden;

            AddEmployee.Visibility = Visibility.Hidden;

            TitleofContent.Visibility = Visibility.Hidden;


            //Then, view all the selected people
            TitleofContent2.Visibility = Visibility.Visible;
            InformationDisplay.Visibility = Visibility.Visible;


            //Get all data from the database
            GetEmployeeData();

        }

        private void Employeelistboxview_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Communication part under construction. Check back later!", "Under construction");
        }
    }
}
