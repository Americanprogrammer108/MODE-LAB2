﻿CREATE TABLE [dbo].[Employeeinfo] (
    [Id]            INT            NOT NULL,
    [name]          NVARCHAR (MAX) NOT NULL,
    [shares]        INT            NOT NULL,
    [datePurchased] DATE           NOT NULL,
    [shareType]     NVARCHAR (MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

