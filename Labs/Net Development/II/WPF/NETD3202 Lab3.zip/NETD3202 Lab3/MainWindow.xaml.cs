﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;


namespace NETD3202_Lab3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void FillDataGrid()
        {
            try
            {
                string dbsconnect = Properties.Settings.Default.connectString;

                //create a new connection
                SqlConnection myconn = new SqlConnection(dbsconnect);

                //open the connection
                myconn.Open();

                string retrieveinfo = "SELECT * FROM Employeesinfo";

                SqlCommand command2 = new SqlCommand(retrieveinfo, myconn);

                //use a SqlDataAdapter
                SqlDataAdapter adapter1 = new SqlDataAdapter(command2);

                //Create the datatable and them populate it 
                DataTable employees = new DataTable("Employeesinfo");
                adapter1.Fill(employees);

                 AllEntries.ItemsSource = employees.DefaultView;

                myconn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //get values from the form
            

            errorMessages.Clear();
            if (buyerName.Text == "" || shareNums.Text == "" || datePurchased.Text == "" || commonRadiobox.IsChecked == false && preferredRadioBox.IsChecked == false)
            {
                if (buyerName.Text == "")
                {
                    errorMessages.AppendText("Buyer Name cannot be left empty!");
                }
                else if (int.TryParse(buyerName.Text, out int invalidbuyer))
                {
                    errorMessages.AppendText("Buyer name cannot be a number!");
                }

                if (shareNums.Text == "")
                {
                    errorMessages.AppendText("\nPlease enter the number of shares!");
                }
                else if (!int.TryParse(shareNums.Text, out int invalidshares))
                {
                    errorMessages.AppendText("\nThe number of shares cannot be a string!");
                }

                if (datePurchased.Text == "")
                {
                    errorMessages.AppendText("\nPlease select a date!");
                }
                /* else if (!int.TryParse(datePurchased.Text, out int invaliddate))
                {
                    errorMessages.AppendText("\nDate cannot be a string!");
                } */

                if (commonRadiobox.IsChecked == false && preferredRadioBox.IsChecked == false)
                {
                    errorMessages.AppendText("\nPlease select an option!");
                }

            }
            else
            {
                //errorMessages.AppendText("Employee created successfully");
                try
                {
                    string name = buyerName.Text;
                    int noofshares = int.Parse(shareNums.Text);
                    string purchaseDate = datePurchased.SelectedDate.ToString();
                    string sharetype = "";

                    if (commonRadiobox.IsChecked == true)
                    {
                        sharetype = "common";
                    }
                    else if (preferredRadioBox.IsChecked == true)
                    {
                        sharetype = "preferred";
                    }

                    //Connect to the database
                    string connecttoDatabase = Properties.Settings.Default.connectString;

                    //create a new connection
                    SqlConnection conn = new SqlConnection(connecttoDatabase);

                    //open the connection
                    conn.Open();

                    string insertShares = "INSERT INTO Employeesinfo (name, numShares, datePurchased, shareType) VALUES ('" + name + "', '" + noofshares + "', '" + purchaseDate + "', '" + sharetype + "')";

                    SqlCommand mycommand = new SqlCommand(insertShares, conn);


                    //execute the query
                    mycommand.ExecuteNonQuery();


                    string selectionQuery = "";
                    if (sharetype == "common")
                    {
                        selectionQuery = "SELECT numCommonShares FROM Shares";
                    }
                    else if (sharetype == "preferred")
                    {
                        selectionQuery = "SELECT numPreferredShares FROM Shares";
                    }

                    SqlCommand command3 = new SqlCommand(selectionQuery, conn);

                    int availableShares = Convert.ToInt32(command3.ExecuteScalar());

                    availableShares = availableShares - noofshares;

                    if (availableShares <= 0)
                    {
                        MessageBox.Show("There is not enough shares available. Sorry", "Not enough shares");
                    }
                    else
                    {
                        string updateQuery = "";
                        if (sharetype == "common")
                        {
                            updateQuery = "UPDATE shares SET numCommonShares = '" + availableShares + "' ";
                            SqlCommand command4 = new SqlCommand(updateQuery, conn);
                            command4.ExecuteScalar();
                        }
                        else if (sharetype == "preferred")
                        {
                            updateQuery = "UPDATE shares SET numPreferredShares = '" + availableShares + "' ";
                            SqlCommand command4 = new SqlCommand(updateQuery, conn);
                            command4.ExecuteScalar();
                        }
                    }

                    MessageBox.Show("Purchase added successfully", "Added");

                    buyerName.Clear();
                    shareNums.Clear();
                    commonRadiobox.IsChecked = false;
                    preferredRadioBox.IsChecked = false;
                    datePurchased.SelectedDate = null;

                    //close the connection
                    conn.Close();

                    


                    //update the information in View Summary
                   /*  conn.Open();
                    string sumofcommonshares = "SELECT SUM(shares) FROM Employeeinfo";
                    
                    SqlCommand command2 = new SqlCommand(sumofcommonshares, conn);

                    SqlDataAdapter sda = new SqlDataAdapter(command2);

                    DataTable employeedatatable = new DataTable();
                    sda.Fill(employeedatatable);

                    conn.Close(); */
                    //numberofCommonSharesSold.Text();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        //if the tab selection has changed, what happens?
        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string tabItem = ((sender as TabControl).SelectedItem as TabItem).Header as string;

            switch(tabItem)
            {
                case "View Summary":
                    try
                    {
                        string conn3 = Properties.Settings.Default.connectString;
                        
                        SqlConnection connect = new SqlConnection(conn3);

                        connect.Open();

                        //Fill up the common shares sold
                        string retrieveSharesQuery = "SELECT SUM(numShares) FROM Employeesinfo WHERE shareType = 'Common'";

                        SqlCommand command1 = new SqlCommand(retrieveSharesQuery, connect);

                        int soldCommonShares = Convert.ToInt32(command1.ExecuteScalar());

                        numberofCommonSharesSold.Text = soldCommonShares.ToString();


                        //Fill up the preferred shares sold
                        string retrieveSharesQuery2 = "SELECT SUM(numShares) FROM Employeesinfo WHERE shareType = 'Preferred'";
                        SqlCommand command2 = new SqlCommand(retrieveSharesQuery2, connect);

                        int soldPreferredShares = Convert.ToInt32(command2.ExecuteScalar());

                        numberofPreferedSharesSold.Text = soldPreferredShares.ToString();


                        //Fill up the number of common shares available
                        string retrieveSharesQuery3 = "SELECT numCommonShares FROM Shares";
                        SqlCommand command3 = new SqlCommand(retrieveSharesQuery3, connect);

                        int availableCommonShares = Convert.ToInt32(command3.ExecuteScalar());
                        CommonSharesAvailable.Text = availableCommonShares.ToString();
                        
                        
                        //Fill up the number of preferred shares available
                        string retrieveSharesQuery4 = "SELECT numCommonShares FROM Shares";
                        SqlCommand command4 = new SqlCommand(retrieveSharesQuery4, connect);

                        int availablePreferredShares = Convert.ToInt32(command4.ExecuteScalar());
                        PreferredSharesAvailable.Text = availablePreferredShares.ToString();


                        //calculate the total common and preferred shares available

                        int howmanycommonsharesavailable = availableCommonShares - soldCommonShares;
                        CommonSharesAvailable.Text = howmanycommonsharesavailable.ToString();

                        int howmanypreferredsharesavailable = availablePreferredShares - soldPreferredShares;
                        PreferredSharesAvailable.Text = howmanypreferredsharesavailable.ToString();

                        connect.Close();


                        //Generate a random number for the revenue
                        Random randomvalue = new Random();
                        int randnum = randomvalue.Next();
                        revenueGenerated.Text = randnum.ToString();
                        
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show("Unable to get data");
                    }
                    break;

                case "View Entries":
                    try
                    {
                        string conn2 = Properties.Settings.Default.connectString;
                        
                        SqlConnection connect = new SqlConnection(conn2);

                        connect.Open();

                        //Fill up the preferred shares sold
                        string retrieveallQuery = "SELECT * FROM Employeesinfo";


                        SqlCommand command1 = new SqlCommand(retrieveallQuery, connect);

                        FillDataGrid();

                        connect.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Unable to get data");
                    }


                    break;

                case "View Objects":
                    MessageBox.Show("Communication part is in progress. Check back later!");
                    /* try
                    {

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Unable to get data");
                    } */
                    break;
            }
        }
    }
}
