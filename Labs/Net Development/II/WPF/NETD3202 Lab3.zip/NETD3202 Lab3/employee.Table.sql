﻿CREATE TABLE [employees].[Table]
(
	[name] NVARCHAR(MAX) NOT NULL PRIMARY KEY, 
    [shares] INT NULL, 
    [datePurchased] DATE NULL, 
    [shareType] NVARCHAR(MAX) NULL
)
