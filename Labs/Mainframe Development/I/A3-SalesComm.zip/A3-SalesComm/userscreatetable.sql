DROP TABLE IF EXISTS users, faculty, students;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users
(
	ID int PRIMARY KEY,
	Password varchar(40),
	FirstName varchar(50),
	LastName varchar(50),
	EmailAddress varchar(90),
	LastAccess date,
	EnrollDate date,
	Enabled boolean,
	Type char(1)
);

CREATE TABLE students
(
	ID int PRIMARY KEY,
	ProgramCode varchar(8),
	ProgramDescription varchar(50),
	Year int
);

CREATE TABLE faculty
(
	ID int PRIMARY KEY,
	SchoolCode varchar(8),
	SchoolDescription varchar(50),
	Office VARCHAR(50),
	Extension int
);

INSERT INTO students(ID, ProgramCode, ProgramDescription, Year)
VALUES(234908108, 'NETD3201', 'Net Development II', 2022);

INSERT INTO students(ID, ProgramCode, ProgramDescription, Year)
VALUES(223900334, 'WEBD4201', 'Web Development - Enterprise', 2023);

INSERT INTO students(ID, ProgramCode, ProgramDescription, Year)
VALUES(102779333, 'SYDE2201', 'Systems Development I', 2022);


INSERT INTO users(ID, Password, FirstName, LastName, EmailAddress, LastAccess, EnrollDate, Enabled, Type)
VALUES(234908324, encode(digest('s83mhLi?3', 'sha1'), 'hex'), 'Grayson', 'Loss', 'grayson.loss1@gmail.com',  '2021-02-09', '2022-01-09', true, 's');

INSERT INTO users(ID, Password, FirstName, LastName, EmailAddress, LastAccess, EnrollDate, Enabled, Type)
VALUES(100832859, encode(digest('54Gba7C!', 'sha1'), 'hex'), 'Ethan', 'Chen', 'chensong108330@gmail.com', '2022-01-04', '2023-02-09', true, 's');

INSERT INTO users(ID, Password, FirstName, LastName, EmailAddress, LastAccess, EnrollDate, Enabled, Type)
VALUES(100111111, encode(digest('s83mhLi?3', 'sha1'), 'hex'), 'Mike', 'Jones', 'mike.jones@gmail.com', '2021-02-01', '2022-02-05', true, 's');


INSERT INTO faculty(ID, SchoolCode, SchoolDescription, Office, Extension)
VALUES(234908108, 'UWO', 'Western University', 'B281', 222);

INSERT INTO faculty(ID, SchoolCode, SchoolDescription, Office, Extension)
VALUES(234929108, 'YU', 'York University', 'D180', 222);

INSERT INTO faculty(ID, SchoolCode, SchoolDescription, Office, Extension)
VALUES(716038770, 'MIT', 'Massachusetts Institute of Technology', 'A477', 222);

